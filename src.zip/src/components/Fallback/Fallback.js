import React from 'react';
import classes from './Fallback.module.css';
function Fallback(){
    return (
        <p>No Investment calculated yet</p>
    );
}

export default Fallback;